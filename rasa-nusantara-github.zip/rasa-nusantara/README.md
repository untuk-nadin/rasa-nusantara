# Rasa Nusantara

Website katalog makanan dengan keranjang, checkout WhatsApp, database Supabase, dan dashboard admin.

## Teknologi
- HTML, CSS, JavaScript
- Supabase (PostgreSQL + Authentication + Row Level Security)
- GitHub Pages (hosting frontend statis)

> GitHub Pages hanya meng-host file website. Database dan login admin berjalan di Supabase.

## 1. Siapkan database Supabase
1. Buat akun di https://supabase.com/ lalu buat project baru.
2. Buka **SQL Editor** pada project.
3. Salin seluruh isi `supabase/schema.sql`, tempel, lalu klik **Run**.
4. Buka **Project Settings → API**. Salin Project URL dan anon/publishable key.
5. Salin `config.example.js` menjadi `config.js` (atau edit `config.js` yang disertakan), lalu isi:
   - `SUPABASE_URL`
   - `SUPABASE_ANON_KEY`
   - `WHATSAPP_NUMBER` dengan nomor WhatsApp bisnis, format internasional tanpa `+`.
6. Jangan pernah memakai `service_role` key di website, GitHub, atau browser.

## 2. Buat akun admin
1. Di Supabase buka **Authentication → Users → Add user**.
2. Buat akun dengan email milik pengelola dan password yang kuat.
3. Buka user tersebut dan salin UUID/ID.
4. Di **SQL Editor**, jalankan perintah berikut dengan UUID akun admin:
   ```sql
   insert into public.admin_users(user_id)
   values ('GANTI-DENGAN-UUID-AKUN-ADMIN');
   ```
5. Buka website, klik **Admin**, lalu login memakai email dan password tadi.

Hanya akun yang UUID-nya ada di `admin_users` yang dapat mengakses data dashboard. Jangan membagikan akun admin.

## 3. Tes di komputer
Pastikan `config.js` sudah dibuat. Buka `index.html` di browser. Jika browser membatasi file lokal, jalankan server lokal sederhana, misalnya ekstensi Live Server di VS Code.

## 4. Publikasikan melalui GitHub Pages
1. Masuk ke GitHub dengan akun `untuk-nadin`.
2. Buat repository baru bernama **rasa-nusantara**.
3. Isi `config.js` dengan URL dan anon/publishable key Supabase (keduanya aman untuk frontend jika RLS aktif), lalu unggah `index.html`, `style.css`, `app.js`, `config.js`, folder `supabase/`, dan `README.md`.
4. Pada repository, buka **Settings → Pages**.
5. Pada **Build and deployment**, pilih **Deploy from a branch**.
6. Pilih branch `main` dan folder `/ (root)`, lalu klik **Save**.
7. Tunggu proses deploy. Alamat situs biasanya:
   `https://untuk-nadin.github.io/rasa-nusantara/`

## 5. Penting sebelum dipakai pelanggan
- Ganti nomor WhatsApp contoh di `config.js`.
- Tambahkan produk asli melalui dashboard admin.
- Tes satu pesanan sampai masuk ke WhatsApp dan tabel `orders` di Supabase.
- Anon/publishable key memang terlihat di frontend; keamanan data bergantung pada kebijakan RLS di `schema.sql`. Jangan pernah menonaktifkan RLS.
- Form pesanan publik hanya boleh menambah order. Admin saja yang dapat membaca dan mengubah status order.
- Untuk operasional bisnis yang lebih serius, pertimbangkan validasi pesanan dan total harga di server-side/Edge Function, pembatasan spam, backup database, dan kebijakan privasi.

## Struktur proyek
```text
rasa-nusantara/
├── index.html
├── style.css
├── app.js
├── config.example.js
├── config.js             # buat sendiri; jangan commit jika berisi konfigurasi privat
├── .gitignore
├── README.md
└── supabase/
    └── schema.sql
```
