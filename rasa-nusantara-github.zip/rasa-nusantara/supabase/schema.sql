-- Jalankan seluruh SQL ini di Supabase > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 100),
  description text default '',
  category text not null default 'Makanan',
  price integer not null check (price > 0),
  image_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null check (char_length(customer_name) between 1 and 80),
  phone text not null check (char_length(phone) between 5 and 24),
  notes text default '',
  items jsonb not null,
  total integer not null check (total > 0),
  status text not null default 'baru' check (status in ('baru','diproses','selesai','dibatalkan')),
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists(select 1 from public.admin_users where user_id = auth.uid());
$$;

alter table public.products enable row level security;
alter table public.admin_users enable row level security;
alter table public.orders enable row level security;

drop policy if exists "Public can view active products" on public.products;
create policy "Public can view active products" on public.products
for select to anon, authenticated using (is_active = true or public.is_admin());

drop policy if exists "Admins manage products" on public.products;
create policy "Admins manage products" on public.products
for all to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "Admins can view own admin record" on public.admin_users;
create policy "Admins can view own admin record" on public.admin_users
for select to authenticated using (user_id = auth.uid());

drop policy if exists "Visitors can create orders" on public.orders;
create policy "Visitors can create orders" on public.orders
for insert to anon, authenticated
with check (
  char_length(customer_name) between 1 and 80
  and char_length(phone) between 5 and 24
  and total > 0
  and jsonb_typeof(items) = 'array'
);

drop policy if exists "Admins can read orders" on public.orders;
create policy "Admins can read orders" on public.orders
for select to authenticated using (public.is_admin());

drop policy if exists "Admins can update orders" on public.orders;
create policy "Admins can update orders" on public.orders
for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- Contoh produk awal (opsional). Jalankan sekali saja.
insert into public.products(name,description,category,price)
values
('Nasi Ayam Rempah','Nasi hangat dengan ayam berbumbu rempah.','Makanan',22000),
('Es Teh Nusantara','Teh segar untuk menemani harimu.','Minuman',8000),
('Pisang Cokelat','Camilan manis dan renyah.','Camilan',12000);
