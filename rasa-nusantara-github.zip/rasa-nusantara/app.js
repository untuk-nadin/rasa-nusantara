(() => {
  const cfg = window.RASA_CONFIG || {};
  const $ = (s) => document.querySelector(s);
  const rupiah = (n) => new Intl.NumberFormat("id-ID", {style:"currency",currency:"IDR",maximumFractionDigits:0}).format(Number(n)||0);
  const escapeHTML = (s="") => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const configured = cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY &&
    !cfg.SUPABASE_URL.includes("PROJECT-ID") && !cfg.SUPABASE_ANON_KEY.includes("YOUR_");
  const db = configured && window.supabase ? window.supabase.createClient(cfg.SUPABASE_URL,cfg.SUPABASE_ANON_KEY) : null;
  let products=[], cart=[], category="Semua", user=null, isAdmin=false;

  $("#year").textContent = new Date().getFullYear();
  const message = (text, error=false) => { $("#admin-message").textContent=text; $("#admin-message").classList.toggle("error",error); };
  const fallbackProducts = [
    {id:"demo-1",name:"Nasi Ayam Rempah",price:22000,category:"Makanan",description:"Nasi hangat dengan ayam berbumbu rempah.",image_url:""},
    {id:"demo-2",name:"Es Teh Nusantara",price:8000,category:"Minuman",description:"Teh segar untuk menemani harimu.",image_url:""},
    {id:"demo-3",name:"Pisang Cokelat",price:12000,category:"Camilan",description:"Camilan manis dan renyah.",image_url:""}
  ];

  async function loadProducts(){
    if(!db){ products=fallbackProducts; $("#menu-status").textContent="Mode demo — hubungkan Supabase untuk data asli."; }
    else {
      const {data,error}=await db.from("products").select("*").eq("is_active",true).order("created_at",{ascending:false});
      if(error){products=fallbackProducts;$("#menu-status").textContent="Gagal memuat database. Periksa konfigurasi Supabase.";console.error(error);}
      else {products=data||[];$("#menu-status").textContent=`${products.length} produk tersedia`;}
    }
    renderCategories();renderProducts();
  }
  function renderCategories(){
    const cats=["Semua",...new Set(products.map(p=>p.category).filter(Boolean))];
    $("#categories").innerHTML=cats.map(c=>`<button class="category-chip ${c===category?"active":""}" data-category="${escapeHTML(c)}">${escapeHTML(c)}</button>`).join("");
    $("#categories").querySelectorAll("button").forEach(b=>b.addEventListener("click",()=>{category=b.dataset.category;renderCategories();renderProducts();}));
  }
  function renderProducts(){
    const term=$("#search").value.toLowerCase();
    const shown=products.filter(p=>(category==="Semua"||p.category===category)&&(`${p.name} ${p.description||""}`.toLowerCase().includes(term)));
    $("#product-grid").innerHTML=shown.length?shown.map(p=>`<article class="product-card"><div class="product-image">${p.image_url?`<img src="${escapeHTML(p.image_url)}" alt="${escapeHTML(p.name)}" loading="lazy" onerror="this.remove()">`:`<span class="product-placeholder">🍽️</span>`}</div><div class="product-info"><span class="product-meta">${escapeHTML(p.category||"Pilihan")}</span><h3>${escapeHTML(p.name)}</h3><p>${escapeHTML(p.description||"Pilihan lezat dari Rasa Nusantara.")}</p><div class="product-bottom"><span class="price">${rupiah(p.price)}</span><button class="add-button" data-add="${escapeHTML(p.id)}" aria-label="Tambah ${escapeHTML(p.name)}">+</button></div></div></article>`).join(""):`<div class="empty-state">Belum ada produk yang cocok.</div>`;
    $("#product-grid").querySelectorAll("[data-add]").forEach(b=>b.addEventListener("click",()=>addToCart(b.dataset.add)));
  }
  $("#search").addEventListener("input",renderProducts);
  function addToCart(id){const p=products.find(x=>String(x.id)===String(id));if(!p)return;const item=cart.find(x=>String(x.id)===String(id));if(item)item.qty++;else cart.push({...p,qty:1});renderCart();}
  function renderCart(){
    const count=cart.reduce((n,x)=>n+x.qty,0),total=cart.reduce((n,x)=>n+x.qty*Number(x.price),0);
    $("#cart-count").textContent=count;$("#cart-total").textContent=rupiah(total);
    $("#cart-items").innerHTML=cart.length?cart.map(p=>`<div class="cart-row"><div class="cart-row-info"><b>${escapeHTML(p.name)}</b><small>${rupiah(p.price)} / item</small></div><div class="qty-controls"><button data-minus="${escapeHTML(p.id)}">−</button><b>${p.qty}</b><button data-plus="${escapeHTML(p.id)}">+</button></div></div>`).join(""):`<div class="empty-state">Keranjang masih kosong 🍃</div>`;
    $("#cart-items").querySelectorAll("[data-minus]").forEach(b=>b.addEventListener("click",()=>changeQty(b.dataset.minus,-1)));
    $("#cart-items").querySelectorAll("[data-plus]").forEach(b=>b.addEventListener("click",()=>changeQty(b.dataset.plus,1)));
  }
  function changeQty(id,delta){const item=cart.find(x=>String(x.id)===String(id));if(!item)return;item.qty+=delta;if(item.qty<=0)cart=cart.filter(x=>String(x.id)!==String(id));renderCart();}
  const openCart=()=>{$("#cart-drawer").classList.add("open");$("#cart-overlay").classList.add("show");};
  const closeCart=()=>{$("#cart-drawer").classList.remove("open");$("#cart-overlay").classList.remove("show");};
  $("#cart-open").addEventListener("click",openCart);$("#cart-close").addEventListener("click",closeCart);$("#cart-overlay").addEventListener("click",closeCart);

  $("#checkout-form").addEventListener("submit",async e=>{
    e.preventDefault();if(!cart.length){alert("Keranjang masih kosong.");return;}
    if(!db){alert("Hubungkan Supabase terlebih dahulu agar pesanan tersimpan ke database.");return;}
    const fd=new FormData(e.currentTarget),name=String(fd.get("customer_name")).trim(),phone=String(fd.get("phone")).trim(),notes=String(fd.get("notes")||"").trim();
    const items=cart.map(p=>({product_id:p.id,name:p.name,price:Number(p.price),quantity:p.qty,subtotal:Number(p.price)*p.qty}));
    const total=items.reduce((s,x)=>s+x.subtotal,0);
    const {data,error}=await db.from("orders").insert({customer_name:name,phone,notes,items,total,status:"baru"}).select("id").single();
    if(error){alert("Pesanan belum tersimpan: "+error.message);return;}
    const lines=items.map(x=>`- ${x.name} x${x.quantity}: ${rupiah(x.subtotal)}`).join("\n");
    const wa=`Halo Rasa Nusantara, saya ingin konfirmasi pesanan:\n${lines}\nTotal: ${rupiah(total)}\nNama: ${name}\nNo. HP: ${phone}\nCatatan: ${notes}\nKode pesanan: ${data.id}`;
    cart=[];renderCart();e.currentTarget.reset();closeCart();
    const number=String(cfg.WHATSAPP_NUMBER||"").replace(/\D/g,"");
    if(number)window.open(`https://wa.me/${number}?text=${encodeURIComponent(wa)}`,"_blank","noopener");
    else alert("Pesanan tersimpan. Atur WHATSAPP_NUMBER di config.js untuk membuka WhatsApp.");
  });

  const openAdmin=()=>{$("#admin-modal").classList.add("show");message("");};
  $("#admin-open").addEventListener("click",openAdmin);$("#admin-close").addEventListener("click",()=>$("#admin-modal").classList.remove("show"));
  $("#admin-modal").addEventListener("click",e=>{if(e.target===$("#admin-modal"))$("#admin-modal").classList.remove("show");});
  async function checkAdmin(){
    if(!db||!user){isAdmin=false;return false;}
    const {data,error}=await db.from("admin_users").select("user_id").eq("user_id",user.id).maybeSingle();
    isAdmin=!error&&!!data;return isAdmin;
  }
  function showDashboard(){
    $("#admin-login").hidden=true;$("#admin-dashboard").hidden=false;$("#admin-email").textContent=user.email||"Admin";
    loadAdminProducts();loadAdminOrders();
  }
  function showLogin(){ $("#admin-login").hidden=false;$("#admin-dashboard").hidden=true; }
  $("#login-form").addEventListener("submit",async e=>{
    e.preventDefault();if(!db){message("Isi config.js dengan kredensial Supabase terlebih dahulu.",true);return;}
    const fd=new FormData(e.currentTarget);const {data,error}=await db.auth.signInWithPassword({email:fd.get("email"),password:fd.get("password")});
    if(error){message("Login gagal: "+error.message,true);return;}
    user=data.user;if(await checkAdmin()){message("Berhasil masuk.");showDashboard();}
    else{await db.auth.signOut();user=null;message("Akun ini belum terdaftar sebagai admin. Minta pemilik proyek menambahkan UUID ke tabel admin_users.",true);}
  });
  $("#logout").addEventListener("click",async()=>{if(db)await db.auth.signOut();user=null;isAdmin=false;showLogin();message("Kamu sudah keluar.");});
  if(db)db.auth.onAuthStateChange(async(_event,session)=>{user=session?.user||null;if(user&&await checkAdmin())showDashboard();else if(!user)showLogin();});
  document.querySelectorAll(".tab").forEach(t=>t.addEventListener("click",()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===t));$("#admin-products").hidden=t.dataset.tab!=="products";$("#admin-orders").hidden=t.dataset.tab!=="orders";}));

  async function loadAdminProducts(){
    if(!isAdmin)return;const {data,error}=await db.from("products").select("*").order("created_at",{ascending:false});
    if(error){message(error.message,true);return;}
    $("#admin-product-list").innerHTML=(data||[]).map(p=>`<div class="admin-list-item"><div><b>${escapeHTML(p.name)}</b><small>${rupiah(p.price)} · ${escapeHTML(p.category)} · ${p.is_active?"Aktif":"Nonaktif"}</small></div><button class="danger-button" data-delete-product="${escapeHTML(p.id)}">Hapus</button></div>`).join("")||"<p class='muted'>Belum ada produk.</p>";
    $("#admin-product-list").querySelectorAll("[data-delete-product]").forEach(b=>b.addEventListener("click",async()=>{if(!confirm("Hapus produk ini?"))return;const {error}=await db.from("products").delete().eq("id",b.dataset.deleteProduct);if(error)message(error.message,true);else{message("Produk dihapus.");await loadAdminProducts();await loadProducts();}}));
  }
  $("#product-form").addEventListener("submit",async e=>{
    e.preventDefault();if(!isAdmin)return;const fd=new FormData(e.currentTarget);
    const payload={name:String(fd.get("name")).trim(),price:Number(fd.get("price")),category:String(fd.get("category")).trim(),image_url:String(fd.get("image_url")||"").trim()||null,description:String(fd.get("description")||"").trim(),is_active:true};
    const {error}=await db.from("products").insert(payload);if(error){message(error.message,true);return;}
    e.currentTarget.reset();message("Produk berhasil ditambahkan.");await loadAdminProducts();await loadProducts();
  });
  async function loadAdminOrders(){
    if(!isAdmin)return;const {data,error}=await db.from("orders").select("*").order("created_at",{ascending:false}).limit(100);
    if(error){message(error.message,true);return;}
    $("#admin-order-list").innerHTML=(data||[]).map(o=>`<div class="admin-list-item"><div><b>${escapeHTML(o.customer_name)} · ${rupiah(o.total)}</b><small>${escapeHTML(o.phone)} · ${new Date(o.created_at).toLocaleString("id-ID")}<br>${escapeHTML((o.items||[]).map(i=>`${i.name} x${i.quantity}`).join(", "))}</small></div><select class="status-select" data-order-status="${escapeHTML(o.id)}"><option value="baru" ${o.status==="baru"?"selected":""}>Baru</option><option value="diproses" ${o.status==="diproses"?"selected":""}>Diproses</option><option value="selesai" ${o.status==="selesai"?"selected":""}>Selesai</option><option value="dibatalkan" ${o.status==="dibatalkan"?"selected":""}>Dibatalkan</option></select></div>`).join("")||"<p class='muted'>Belum ada pesanan masuk.</p>";
    $("#admin-order-list").querySelectorAll("[data-order-status]").forEach(s=>s.addEventListener("change",async()=>{const {error}=await db.from("orders").update({status:s.value}).eq("id",s.dataset.orderStatus);message(error?error.message:"Status pesanan diperbarui.",!!error);}));
  }
  if(!configured){$("#menu-status").textContent="Mode demo. Ikuti README untuk menghubungkan database Supabase."; }
  loadProducts();renderCart();
})();