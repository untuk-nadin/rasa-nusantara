// Salin file ini menjadi config.js, lalu isi dari Supabase Project Settings > API.
// URL dan anon/publishable key memang dipakai di browser. JANGAN pernah masukkan service_role key.
window.RASA_CONFIG = {
  SUPABASE_URL: "https://PROJECT-ID.supabase.co",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY",
  WHATSAPP_NUMBER: "6281234567890" // Ganti dengan nomor WhatsApp toko, format internasional tanpa tanda +
};